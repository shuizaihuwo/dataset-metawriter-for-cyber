"""数据集标注工具CLI入口点."""

from .cli import main

if __name__ == "__main__":
    main()